# Mini Project Assessment – Express.js REST API

## Objective
Create a simple REST API using Express.js demonstrating CRUD operations and error handling.

## Setup Instructions

1. Install dependencies:
   ```
   npm install express
   ```

2. Run the server:
   ```
   node index.js
   ```

3. API runs at `http://localhost:3000`

## API Routes

### Root
- `GET /`  
  Response: `"Hello, World!"`

### Items

- `GET /items`  
  Retrieve all items.

- `GET /items/:id`  
  Retrieve an item by ID.

- `POST /items`  
  Create an item.  
  Body: `{ "name": "New Item", "description": "Description here" }`

- `PUT /items/:id`  
  Update an item by ID.  
  Body: `{ "name": "Updated Name", "description": "Updated Desc" }`

- `DELETE /items/:id`  
  Delete an item by ID.

## Example Request (Postman)

**POST /items**

```json
{
  "name": "Test Item",
  "description": "Testing create item"
}
```

Response:
```json
{
  "id": 3,
  "name": "Test Item",
  "description": "Testing create item"
}
```
